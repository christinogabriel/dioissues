# GitHub Stats

<table>
  <tr>
    <td>
      Temas
    </td>
    <td>
       <a href="https://github.com/anuraghazra/github-readme-stats/blob/master/themes/README.md">
          github-readme-stats/themes/README.md
       </a>
    </td>
  </tr>
  <tr>
    <td>
      Fonte
    </td>
    <td>
       <a href="https://github.com/anuraghazra/github-readme-stats">
          anuraghazra/github-readme-stats
       </a>
    </td>
  </tr>
</table>

## Card - Stats

| Preview | Parameters |
|:-------:|:----------:|
| ![GitHub Stats](https://github-readme-stats.vercel.app/api?username=SEUUSERNAME&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF) | `theme=transparent` `bg_color=000` `border_color=30A3DC` `show_icons=true` `icon_color=30A3DC` `title_color=E94D5F` `text_color=FFF`|

```
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=SEUUSERNAME&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
```

## Card - Most Used Languages
| Preview | Parameters |
|:-------:|:----------:|
| ![Most Used Languages](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=elidianaandrade&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF) | `bg_color=000` `border_color=30A3DC` `title_color=E94D5F` `text_color=FFF`|

```
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=SEUUSERNAME&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
```

### Card - Most Used Languages Compact

| Preview | Parameters |
|:-------:|:----------:|
| ![Most Used Languages](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=elidianaandrade&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)| `layout=compact` `bg_color=000` `border_color=30A3DC` `title_color=E94D5F` `text_color=FFF`|

```
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=SEUUSERNAME&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
```

## Card - Repository

| Preview | Parameters |
|:-------:|:----------:|
| [![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=digitalinnovationone&repo=roadmaps&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/digitalinnovationone/roadmaps)| `bg_color=000` `border_color=30A3DC` `icon_color=30A3DC` `title_color=E94D5F` `text_color=FFF`|

```
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=SEUUSERNAME&repo=SEUREPOSITORIO&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/SEUUSERNAME/SEUREPOSITORIO)
```