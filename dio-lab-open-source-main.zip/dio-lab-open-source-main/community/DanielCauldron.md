 ## Hello! I'm Daniel Caldeirão👋

Busco constantemente aprimorar meu conhecimento e habilidades para acompanhar o ritmo acelerado do mundo 🌍 da tecnologia.

       "A busca pelo conhecimento é a estrada que nos leva ao crescimento pessoal e à compreensão do mundo."

##

### My Stats

<div>
  <a href="https://github.com/
DanielCauldron">
<div style="display: flex;">
 <img src="https://github-readme-stats.vercel.app/api?username=Danielcauldron&show_icons=true&theme=transparent" style="height: 200px; width: 45%;" />
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Danielcauldron&layout=compact&theme=transparent" style="height: 200px; width: 40%;" />
</div>
 </a>
</div>

##


<div>
 <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" width="50"/>
 <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" width="50"/>
 <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" width="50" />
 <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" width="50" />
 <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" width="50" />
 <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/github/github-original.svg" width="50" />
</div>
  Contacts

<div>
  <a href="https://www.linkedin.com/in/daniel-caldeir%C3%A3o-43b01b244/">
    <img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white" />
  </a>
 <a href = "mailto:dfcaldeirao@gmail.com"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white"></a>

</div>


