# Rodeuz

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-252525?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/rodrigo-nicacio-tavares-661241218/) [![Instagram](https://img.shields.io/badge/Instagram-252525?style=for-the-badge&logo=instagram)](https://www.instagram.com/roodeus/)

## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4) ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

## Github Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Rodeuz&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas Contribuições

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Rodeuz&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/SEUUSERNAME/SEUREPOSITORIO)
