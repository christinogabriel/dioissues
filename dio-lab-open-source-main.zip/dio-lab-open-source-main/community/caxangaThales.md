# Caxangá Thales   
Prazer, Meu nome é Thales, esse é meu primeiro contato com o mundo dos desenvolvedores, espero que em breve esteja bem adaptado à como fazer as coisas.

## Conecte- se Comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/caxangaThales/)
[![Twitter](https://img.shields.io/badge/Twitter-000?style=for-the-badge&logo=twitter)](https://twitter.com/Tcaxangaa)

## Interesses Pessoais

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
	![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

## GitHub Stats

[![GitHub Streak](https://streak-stats.demolab.com/?user=SEUUSERNAME&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)
