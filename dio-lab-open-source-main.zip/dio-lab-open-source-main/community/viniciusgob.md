
# Projeto Open Source

Contribuindo em um Projeto Open Source no GitHub pelo dio.


## Contribuindo

Contribuições são sempre bem-vindas!

Veja `vinicius.md` para saber como começar.

Por favor, siga o `código de conduta` desse projeto.


## 🚀 Sobre mim
Tenho conhecimento em SQL, bancos como POSTGRE e ORACLE. Atualmente trabalho com analista de suporte em um sistema de WMS e estou mergulhando de cabeça para desenvolvimento de software, focando primeiramente nas linguagens JAVA e JAVASCRIPT


## 🔗 Links
[![portfolio](https://img.shields.io/badge/my_portfolio-000?style=for-the-badge&logo=ko-fi&logoColor=white)](https://instagram.com/viniciusgob)
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/vinicius-gomes-barros-4b8ba9199/)

