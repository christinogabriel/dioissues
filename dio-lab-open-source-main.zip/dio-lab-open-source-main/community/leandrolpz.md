# leandrolpz

## Sobre mim
Meu nome é Leandro Penha, cursei Análise e Desenvolvimento de Sistemas no "Senai Cotia - Ricardo Lerner", duração de 1 ano e meio. Gosto da área de tecnologia e quero aprender mais, me tornar realmente alguém que domina a linguagem, atualmente me sinto atraído pelo front-end. Espero que gostem do meu perfil e olhem alguns projetos. Peço que me sigam no LinkedIn e que se sintam a vontade de me chamar. 

## conecte-se comigo
[![GitHub](https://img.shields.io/badge/GitHub-ec63a1?style=for-the-badge&logo=github&logoColor=0E76A8)](https://github.com/leandrolpz)

[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/lean_lp/)

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/leandro-penha-de-paula-80396522b/)


## GitHub Stats
<a href="https://github.com/leandrolpz">
<img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=leandrolpz&layout=compact&langs_count=7&theme=nord"/>

![Leandro GitHub stats](https://github-readme-stats.vercel.app/api?username=Leandrolpz&show_icons=true&theme=radical)
