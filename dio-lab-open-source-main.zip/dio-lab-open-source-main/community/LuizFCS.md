<img align="right" src="https://user-images.githubusercontent.com/90050988/234340765-0719bc83-dce5-4121-ab81-4874cc8b3709.png" width="300"/> 

#  *Olá me chamo Luiz*
  
  Sou apaixonado por tecnologia, recém formado em Análise e Desenvolvimento de Sistemas!
  
  ## *Interesses*
  
  A procura de uma oportunidade na área de programação, estágio e júnior.
  
  Tenho 36 anos, sou natural de São José dos Campos/SP, adoro aprender coisas novas e amo viajar!
  
  Focado nos estudos, aprendendo lógica, linguagens e frameworks!!!
  

<div>
  <a href="https://github.com/Luizfcs35/Luizfcs35/">
  <img height="180em" width="360em" src="https://github-readme-stats.vercel.app/api?username=Luizfcs35&show_icons=true&theme=codeSTACKr&border_radius=1.7em" />
    
  <img height="190em" width="360em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Luizfcs35&layout=compact&theme=codeSTACKr&border_radius=1em" />
</div> 

##  *Conhecimentos*
  
* HTML5
* CSS3
* JS - aprendendo
* Bootstramp
* SQL
* REACTJS - aprendendo
* PYTHON Basic

<div align="center" width="100%">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-plain.svg" width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-plain.svg" width="50"/>   
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg"  width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg" width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" width="50" />     
</div>