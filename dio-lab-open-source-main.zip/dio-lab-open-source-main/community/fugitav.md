
# GitHub Fugita V

Olá, sou Vitor, analista júnior, com 3 anos de experiência na área.




## 🔗 Links

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/VitorFugita)
[![instagram](https://img.shields.io/badge/instragram-pink?style=for-the-badge&logo=instagram&logoColor=black)](https://instragram.com/fugitagv)


## 🛠 Habilidades
JavaScript, HTML, CSS, ReactJS, TypeScript.


PHP, Angular, OracleRightNow e AWS.

