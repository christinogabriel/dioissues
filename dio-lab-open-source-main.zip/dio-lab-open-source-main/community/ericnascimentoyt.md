<h1 align="left">Hi dear 👋, I'm Eric Nascimento</h1>
<p align="left"> <img src="https://komarev.com/ghpvc/?username=ericnascimento4k&color=yellow" alt="Profile views" /> </p>

- 🔥 Integration Analyst | Solution Architect | Vtex Implementation Certificat | Digital commerce expert | Software Developer Web

- 💬 Ask me about **DB, Vtex, Totvs e Front-end**

- ⚡ "I'm a big believer in luck, and I've found that the harder I work, the luckier I get." ( Thomas Jefferson )

<br><br>

## 🛠 &nbsp;Tech Stack

![HTML](https://img.shields.io/badge/-HTML-05122A?style=flat&logo=HTML5)&nbsp;
![CSS](https://img.shields.io/badge/-CSS-05122A?style=flat&logo=CSS3&logoColor=1572B6)&nbsp;
![JavaScript](https://img.shields.io/badge/-JavaScript-05122A?style=flat&logo=javascript)&nbsp;
![Git](https://img.shields.io/badge/-Git-05122A?style=flat&logo=git)&nbsp;
![GitHub](https://img.shields.io/badge/-GitHub-05122A?style=flat&logo=github)&nbsp;
![Visual Studio Code](https://img.shields.io/badge/-Visual%20Studio%20Code-05122A?style=flat&logo=visual-studio-code&logoColor=007ACC)&nbsp;
![Snake animation](https://github.com/codethi/codethi/blob/output/github-contribution-grid-snake.svg)


## 🔭 GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ericnascimentoyt&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=ericnascimentoyt&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

<br>

## 👨🏽 &nbsp;Social Links

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/ericebpro/)

<p align="left" style="background:blue">
<a href="https://linkedin.com/in/ericnascimentoyt/" target="_blank">
  <img align="center" src="https://img.shields.io/badge/-ericnascimentoyt-05122A?style=flat&logo=linkedin" alt="linkedin"/>
</a>
<a href="https://instagram.com/ericnascimentoyt" target="_blank">
 <img align="center" src="https://img.shields.io/badge/-ericnascimentoyt-05122A?style=flat&logo=instagram" alt="instagram"/>
</a>
</p>
