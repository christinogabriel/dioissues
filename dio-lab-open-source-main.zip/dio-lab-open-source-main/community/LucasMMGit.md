# Lucas Moreira Martins

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-FFFFFF?style=for-the-badge&logo=linkedin&logoColor=0077B5)](https://www.linkedin.com/in/lucasmmaerospace/)

## Habilidades
- <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/Microsoft_Office_Excel_%282019%E2%80%93present%29.svg/2203px-Microsoft_Office_Excel_%282019%E2%80%93present%29.svg.png" height="10"> **Excel**
- <img src="https://cdn-icons-png.flaticon.com/512/25/25231.png" height="10">  **GitHub**
- <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/Matlab_Logo.png/667px-Matlab_Logo.png" height="10"> **Matlab**
- <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/New_Power_BI_Logo.svg/2048px-New_Power_BI_Logo.svg.png" height="10"> **Power BI**
- <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Python-logo-notext.svg/1869px-Python-logo-notext.svg.png" height="10"> **Python**
- <img src="https://www.r-project.org/logo/Rlogo.png" height="10">  **R**
- <img src="https://img.favpng.com/15/10/6/microsoft-sql-server-stored-procedure-table-query-language-png-favpng-VvKMjrErMuBNAGmTyhuEURAxZ.jpg" height="10"> **SQL**

## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=LucasMMGit&theme=transparent&border_color=0497EF&show_icons=true&icon_color=0497EF&title_color=EF5C04&text_color=808080)

## Minhas contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=LucasMMGit&repo=dio-lab-open-source&theme=transparent&border_color=0497EF&show_icons=true&icon_color=0497EF&title_color=EF5C04&text_color=808080)](https://github.com/LucasMMGit/dio-lab-open-source)