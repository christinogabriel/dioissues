<div align="center">
<img align="center" height="350px" width="350px" alt="GIF" src="https://i.giphy.com/l44Qqz6gO6JiVV3pu.gif"/>
 </div>
<br />

## Hi There!
<p>Eu sou a Bruna e moro atualmente em São Paulo/SP. Sou advogada e agora também desenvolvedora full stack formada pela Generation Brasil e Ada Tech!</p>

<p>Já atuei como desenvolvedora em duas empresas e agora busco uma nova oportunidade!</p>
<p>No momento estou estudando Java, Angular e MySQL. <br> No futuro pretendo estudar .Net, clojure e aws!</p> 
<p>Amo viagens, livros, pets, comer bem e aprender coisas novas. Estou buscando me aperfoiçoar na área de desenvolvimento de software!</p>
<hr>
<p>
I'm Bruna and I currently live in São Paulo/SP, Brazil. I'm a lawyer and now also a full stack developer formed by Generation Brasil and Ada Tech!
<br>At the moment I'm studying Java, Angular and MySQL.
<br>In the future I intend to study .Net, clojure and aws!
<br>I love traveling, books, pets, discover new foods and learning new things. I'm looking to improve myself in the area of software development!
</p>

<div align="center">
  <a href="https://github.com/Brumidori">
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Brumidori&layout=compact&langs_count=7&theme=dracula"/>
</div>
  
<br>
:rocket: Conhecimentos em: <br>

<a src="https://www.javascript.com/"><img src="https://img.icons8.com/color/48/000000/javascript.png"/></a>
<a src="https://visualstudio.microsoft.com/"><img src="https://img.icons8.com/color/48/000000/visual-studio.png"/></a>
<a src="https://github.com/"><img src="https://img.icons8.com/color/48/000000/github--v1.png"/></a>
<a src="https://www.w3schools.com/css/"><img src="https://img.icons8.com/color/48/000000/css3.png"/></a>
<a src="https://www.w3schools.com/html/"><img src="https://img.icons8.com/color/48/000000/html-5.png"/></a>
<a src="https://www.java.com/pt-BR/"><img src="https://icons.iconarchive.com/icons/tatice/cristal-intense/48/Java-icon.png"/></a>
<a src="https://spring.io/projects/spring-boot"><img src="https://a.fsdn.com/allura/mirror/spring-boot/icon?1605202581"/></a>
<a src="https://www.mysql.com/"><img src="https://icons.iconarchive.com/icons/papirus-team/papirus-apps/48/mysql-workbench-icon.png"/></a>
<br><br>
  
📬 Conecte-se comigo nas redes sociais: <br>
[![LinkedIn](https://icons.iconarchive.com/icons/alecive/flatwoken/48/Apps-Linkedin-icon.png "quan-le-5932b8160")](https://www.linkedin.com/in/bruna-midori-yassuda/)


