### Welcome to my repositories👨‍💻
Hey, how's it going? I'm a Computer Engineering student, currently in the fifth semester, I got to know the technology area after taking a technical course in mechatronics, and since then I've been exploring this incredible world of technology!

<div>
  <a href="https://github.com/JoaoMichelS">
  <img height="179em" src="https://github-readme-stats-sigma-five.vercel.app/api?username=joaomichels&show_icons=true&theme=tokyonight&count_private=true" />
  <img align="right" height="179em" src="https://github-readme-stats-sigma-five.vercel.app/api/top-langs/?username=JoaoMichelS&layout=compact&theme=tokyonight"/>
</div>
<br>
  
<div  align="center"> 
  <div style="display: inline_block"><br>
    <img align="left" height="250" alt="coding-time" src="code.gif">
    <h1 align="center">Technologies</h1>
    <img align="center" alt="Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
    <img align="center" alt="Java" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg">
    <img align="center" alt="Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
    <img align="center" alt="Ts" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">
    <img align="center" alt="React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
    <img align="center" alt="HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
    <img align="center" alt="CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
   </div>
    
  
  <h1 align="center">Social Media</h1>
    <a href = "https://www.linkedin.com/in/joaomichels/">
      <img width="25" src="linkedin.svg">
    </a>
    <a href = "mailto: jovitor931@gmail.com">
      <img width="30" src="gmail.svg">
    </a>
    <a href = "https://www.instagram.com/_joaomichel/">
      <img width="25" src="instagram.png">
    </a>
</div>
  
  
![Snake animation](https://github.com/joaomichels/joaomichels/blob/output/github-contribution-grid-snake.svg)