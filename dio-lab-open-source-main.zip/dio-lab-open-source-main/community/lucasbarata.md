<img align="right" src="https://user-images.githubusercontent.com/90050988/234340765-0719bc83-dce5-4121-ab81-4874cc8b3709.png" width="300"/> 

#  *Olá me chamo Lucas*
  
  Sou apaixonado por tecnologia, atualmente estou como Analista de Dados Jr na V4 Saman & Co.!
  
  ## *Interesses*
  
  Busco no TI uma forma de mudar a minha vida, visto que venho de uma familia classe media baixa de uma zona rural.
  
  Tenho 23 anos, sou natural de Cachoeiro de Itapemirim/ES, adoro aprender coisas novas e amo viajar!
  
  Focado nos estudos, aprendendo lógica, linguagens e frameworks!!!
  

##  *Conhecimentos*
  
* HTML5
* CSS3
* JS
* PHP
* Bootstramp
* SQL
* PYTHON

<div align="center" width="100%">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-plain.svg" width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-plain.svg" width="50"/>   
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg"  width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg"  width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg" width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" width="50"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" width="50" />     
</div>