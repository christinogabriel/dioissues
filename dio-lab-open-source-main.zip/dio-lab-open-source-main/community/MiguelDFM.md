# Miguel Fernandes

## Sobre mim :
Olá sou de Portugal e parabéns pela vossa plataforma, inicei há pouco tempo estudos na área de T.I ,
então não tenho ainda muito a dizer sobre essa área .
Estudei psicologia, nutrição, um pouco de medicinas naturais, trabalho também com turismo, 
e sou escritor amador, estou também interessado em inteligência artifical, sustentabilidade e energias renováveis, por isso acho que o caminho da tecnológia informática é um importante passo.

## conecte-se comigo :
[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/miguel.df.79/)

## outros blogues :
http://luzanjobranco.blogspot.com/

https://mundosnaturais.blogspot.com/


##
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=MiguelDFM&bg_color=147&border_color=20A7FC&title_color=ABCB7F&text_color=EEE)
