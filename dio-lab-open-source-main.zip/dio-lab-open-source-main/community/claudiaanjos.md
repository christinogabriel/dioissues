# Claudia Anjos

<p align="center">
   Meu nome é Claudia e sou apaixonada por dados 📈. 
<p align="center">
   No meu github você encontrará diversos projetos voltados para essa área, incluindo análises exploratórias, modelos de machine learning e visualizações de dados.
<p align="center">
Tenho participado de bootcamps, treinamentos técnicos e cursos focados em dados. 
    Atualmente, estou software engineer, buscando sempre novos desafios e oportunidades para aprimorar minhas habilidades na área de dados.
<p align="center">
Sinta-se à vontade para explorar meus projetos e, se tiver alguma dúvida ou sugestão, não hesite em entrar em contato! 🤝 
</p>
<br>

<p align="center">
    <a href="https://github.com/claudiaanjos" target="_blank">
        <img  src="https://img.shields.io/badge/claudiaanjos-%23100000.svg?&style=for-the-badge&logo=github&logoColor=white&link=mailto:https://github.com/claudiaanjos">
    </a>
</p>