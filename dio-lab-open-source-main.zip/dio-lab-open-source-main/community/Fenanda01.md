## Perfil Fenanda01

### Sobre

Olá, Sou **Fernanda Cavalcante** estatística formada pela UFRN, gosto de aprender coisas novas diariamente não necessáriamente coisas ligadas ao mercado de trabalho.

### Github
[Fenanda01](https://github.com/Fenanda01/dio-lab-open-source)

### Likidin
[Fernanda Cavalcante](linkedin.com/in/fernanda-cavalcante-631554b2)

### Tecnológias que conheço (algumas conheci na DIO)

![Github](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSprMMaYagKo7XAbx282fXg8wyisybDF3b9Iw&usqp=CAU)

![Docker](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQB--kQ3qZkabOBf1-f51nWAzJYbggP-bvkDBwwk7ZPUSPUqm2hM6L3H9fNgKE3gGyPido&usqp=CAU)

![R](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPisLhutPFPZC59PkXKrhdDePo3gHAdtb7n5usp0AxmcMjjv1I2ZJ9NdWECDS81iG5N0c&usqp=CAU)

![Pyton](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4ii4_6NE2r_GhG6m_ZWtwwadDgOy46vp2lw&usqp=CAU)

