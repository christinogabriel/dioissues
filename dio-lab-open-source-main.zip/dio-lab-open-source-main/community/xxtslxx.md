## Oiii eu sou Tassio Lima, Estudante de Analise e Desenvolvimento de Sistemas!

<div align="center">
  <a href="https://github.com/xxtslxx">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=xxtslxx&show_icons=true&theme=chartreuse-dark&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=xxtslxx&layout=compact&langs_count=7&theme=chartreuse-dark"/>
</div>
 <div style="display: inline_block"><br>
  <img align="center" alt="Tassio-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Tassio-Ts" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">
  <img align="center" alt="Tassio-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="Tassio-Java" height="30" width="40" src="https://github.com/devicons/devicon/blob/master/icons/java/java-original.svg">
  <img align="center" alt="Tassio-Node" height="30" width="40" src="https://github.com/devicons/devicon/blob/master/icons/nodejs/nodejs-plain.svg">
</div>
  
  ##
  
 <div>   
  <a href="https://instagram.com/tassio_limar95" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" 
                                                                      
  <a href="https://www.linkedin.com/in/tassio-lima-6485bb143/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
 
   ![Snake animation](https://github.com/xxtslxx/tassiolima/blob/output/github-contribution-grid-snake.svg)
</div>
