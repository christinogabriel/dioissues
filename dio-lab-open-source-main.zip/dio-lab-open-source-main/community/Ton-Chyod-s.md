### Oi eu sou Klayton 👋


<div>
  ### Rede sociais!!
  
  [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ton-chyod-s/)
  [![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/ArqKdias/)
  [![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/ton_chyod_s/)

</div>


![Ton-Chyod-s GitHub stats](https://github-readme-stats.vercel.app/api?username=Ton-Chyod-s&show_icons=true&theme=dracula)

[![GitHub Streak](https://streak-stats.demolab.com/?user=Ton-Chyod-s&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

### Hailidades!!

<div style="display: inline_block"><br>
<img align="center" alt="Klay-Python" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg">
  <img align="center" alt="Klay-Csharp" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/csharp/csharp-original.svg">
<img align="center" alt="Klay-Csharp" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg">
<img align="center" alt="HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
<img align="center" alt="CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
<img align="right" alt="Gif" height="150" style="border-radius:50px;" src="https://freepngimg.com/thumb/technology/35586-4-robot.png">
</div>

