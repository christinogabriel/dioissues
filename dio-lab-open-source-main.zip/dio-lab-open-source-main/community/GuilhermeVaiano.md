# **Guilherme Vaiano**
Olá! Eu sou o Guilherme Vaiano, sou estudante da Análise e Desenvolvimento de Sistemas da Fatec-SP. Sou técnico em Marketing (formado através da Etec Martin Luther King) e atualmente estou à procura de um estágio na área de TI. Estou procurando me desenvolver nas minhas duas áreas de interesse, que é dados e back-end (mas todo conhecimento é bem-vindo).

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/guinmendonca/)
[![E-mail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:guivnmendonca@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/guilherme-vaiano/)


### Habilidades
![JAVA](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=java&logoColor=white)
![Spring](https://img.shields.io/badge/Spring-6DB33F?style=for-the-badge&logo=spring&logoColor=white)
![T-SQL](https://img.shields.io/badge/Microsoft_SQL_Server-CC2927?style=for-the-badge&logo=microsoft-sql-server&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
![MySQL](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white)

### GitHub Stats
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=GuilhermeVaiano&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=GuilhermeVaiano&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


### Meus Principais Projetos
[![Colocando em prática os conhecimentos de Spring](https://github-readme-stats.vercel.app/api/pin/?username=GuilhermeVaiano&repo=Lista_de_jogos&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)
[![Colocando em prática os conhecimentos de banco de dados e JPA](https://github-readme-stats.vercel.app/api/pin/?username=GuilhermeVaiano&repo=jogoDaVelhaRanqueado&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/GuilhermeVaiano/jogoDaVelhaRanqueado)

