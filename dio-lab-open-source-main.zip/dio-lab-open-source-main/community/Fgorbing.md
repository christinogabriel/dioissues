# Fernanda Görbing
Sou protagonista do meu desenvolvimento, busco constantemente novos conhecimentos. Inquieta questionadora e inconformada, gosto de desafios e mudanças. Aos 40 anos sou mãe de um bebê de 1 ano. A maternidade com certeza é meu maior desafio. Logo depois tem sido adquirir as habilidades necessarias para me tornar Ciêntista de Dados. Nisso a DIO vem sendo minha grande aliada

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://web.dio.me/users/fgorbing/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:fgorbing@hotmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/fernanda-g%C3%B6rbing/)
[![Intagram](https://img.shields.io/badge/-Instagram-000?style=for-the-badge&logo=Instagram&logoColor=30A3DC)](https://www.instagram.com/fernandagorbing/)
[![Facebook](https://img.shields.io/badge/-Facebook-000?style=for-the-badge&logo=Facebook&logoColor=30A3DC)](https://www.facebook.com/fernanda.gorbing/)


### Habilidades

![SQL](https://img.shields.io/badge/PostgreSQL-000?style=for-the-badge&logo=PostgreSQL&logoColor=E94D5F)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python&logoColor=30A3DC)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Fgorbing&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

