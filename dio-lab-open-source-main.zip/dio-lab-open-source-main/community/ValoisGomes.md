# Valois Gomes

## Resumo 👋

Dev Fullstack, apaixonado por tudo que faz, viciado em aprender e sempre em busca de ajudar as pessoas a extraírem o melhor de si. A adrenalina dos grandes desafios me motiva, a busca por resultados incríveis me fortalece, tecnologia e inovação alimentam meu enorme apetite para o novo. Derrotas, medos e mudanças me tornam cada dia mais forte, minha história me forjou o que sou e essa é uma história escrita em uma livro que ainda possui muita páginas em branco e que continuarei escrevendo com força, foco e determinação. O não eu já tenho, vou em Busca do SIM que eu quero!

## Contatos

[![GitHub followers](https://img.shields.io/github/followers/tuliosabino?style=social)](https://github.com/valoisgomes)

[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/valoisgomes/)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/valois-gomes/)
[![Whatsapp](https://img.shields.io/badge/whatsapp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/5583981017721)
[![Gmail](https://img.shields.io/badge/gmail-EA4335?style=for-the-badge&logo=gmail&logoColor=white)](mailto:valoisgomes84@gmail.com)

## Estatísticas do GitHub

![Estatísticas do GitHub](https://github-readme-stats.vercel.app/api?username=valoisgomes&show_icons=true&theme=dark)

## Contribuições

![Contribuições](https://github-readme-streak-stats.herokuapp.com/?user=valoisgomes&theme=dark)

## Linguagens Mais Populares

![Linguagens Mais Populares](https://github-readme-stats.vercel.app/api/top-langs/?username=Albino-Marques&layout=compact&langs_count=7&theme=dark)

## Linguagens de programação

![Python](https://img.shields.io/badge/Python-FFEF00?style=for-the-badge&logo=python&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-3776AB?style=for-the-badge&logo=typescript&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F5E834?style=for-the-badge&logo=JavaScript&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML-E34F26?style=for-the-badge&logo=HTML5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS-1572B6?style=for-the-badge&logo=CSS3)

## Bibliotecas e Frameworks

![Django](https://img.shields.io/badge/Django-092E20?style=for-the-badge&logo=Django)
![NestJS](https://img.shields.io/badge/Nestjs-21759B?style=for-the-badge&logo=Nestjs)
![Angular](https://img.shields.io/badge/Angular-F7262D?style=for-the-badge&logo=angular)
