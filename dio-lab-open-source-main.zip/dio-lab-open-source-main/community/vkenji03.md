# Vítor Kenji Okano Yoshida

Tenho 20 anos, sou estudante de ciência da computação na unicamp e estou no quinto semestre. Tenho interesse na área de dados e sou apaixonado por tecnologia no geral.

## Conecte-se comigo
[MEU PERFIL NA DIO](https://www.linkedin.com/in/SEUUSERNAME/)

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
